package demo;

import java.util.concurrent.Executors;
import java.time.Instant;
import java.time.Duration;

public class VirtualThreadsExample {
    public static void main(String[] args) {
        Instant start = Instant.now();

        // Creates an unbounded executor that spawns a new virtual thread per task
        try (var executor = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int i = 0; i < 10_000; i++) {
                int taskId = i;
                executor.submit(() -> {
                    try {
                        // The JVM pauses this virtual thread and frees up the OS thread!
                        Thread.sleep(Duration.ofSeconds(1)); 
                        System.out.println("Task " + taskId + " finished on " + Thread.currentThread());
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                });
            }
        } // Executor auto-closes here, waiting for all tasks to finish

        Instant end = Instant.now();
        System.out.println("Total time taken: " + Duration.between(start, end).toSeconds() + " seconds");
    }
}