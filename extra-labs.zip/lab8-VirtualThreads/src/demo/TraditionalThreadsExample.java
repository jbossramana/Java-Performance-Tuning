package demo;

import java.util.concurrent.Executors;
import java.time.Instant;
import java.time.Duration;

public class TraditionalThreadsExample {
    public static void main(String[] args) {
        Instant start = Instant.now();

        // Limit to 100 threads so we don't crash the Operating System
        try (var executor = Executors.newFixedThreadPool(100)) {
            for (int i = 0; i < 10_000; i++) {
                int taskId = i;
                executor.submit(() -> {
                    try {
                        // Simulating a 1-second network or database call
                        Thread.sleep(Duration.ofSeconds(1)); 
                        System.out.println("Task " + taskId + " finished on " + Thread.currentThread());
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                    }
                });
            }
        } // Executor auto-closes here, waiting for all tasks to finish

        Instant end = Instant.now();
        System.out.println("Total time taken: " + Duration.between(start, end).toSeconds() + " seconds");
    }
}