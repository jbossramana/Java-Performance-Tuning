package demo.code.srp;

//PayslipGenerator class responsible for generating payslips
public class PayslipGenerator {
	
 public  void generatePayslip(Employee employee) 
 {
     // Method to generate payslip
     // Code for generating payslip
 }
}