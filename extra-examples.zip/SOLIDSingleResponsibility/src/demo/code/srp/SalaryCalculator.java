package demo.code.srp;

//SalaryCalculator class responsible for calculating salaries
public class SalaryCalculator 
{
 public  double calculateSalary(Employee employee) {
     // Method to calculate salary
     // Code for salary calculation
	 return 10000;
 }
}