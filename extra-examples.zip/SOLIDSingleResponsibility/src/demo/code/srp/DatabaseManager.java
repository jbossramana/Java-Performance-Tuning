package demo.code.srp;

//DatabaseManager class responsible for database interactions
public class DatabaseManager {
	
 public  void saveToDatabase(Employee employee) {
     // Method to save employee data to database
     // Code for database interaction
 }
 
}