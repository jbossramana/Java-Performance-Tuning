package demo.code.dip;

public interface IAccountService {

	 void createAccount(Account account);
	 Account getAccountById(int id);
	    // Other methods for account-related operations...
	    
}
