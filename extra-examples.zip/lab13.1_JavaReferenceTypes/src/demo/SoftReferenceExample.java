package demo;

import java.lang.ref.SoftReference;

public class SoftReferenceExample {
    public static void main(String[] args) {
        // Creating a strong reference to a String object
        String strongReference = "Hello, StrongReference!";
        System.out.println("Strong reference created: " + strongReference);

        // Creating a SoftReference to the same String object
        SoftReference<String> softReference = new SoftReference<>(strongReference);

        // Nullifying the strong reference
        strongReference = null;

        // Retrieving the object from the SoftReference
        String str = softReference.get();

        // Printing the object retrieved from the SoftReference
        System.out.println("Object retrieved from SoftReference: " + str);
    }
}
